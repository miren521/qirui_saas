<?php
/**
 * KirySaaS--------||bai T o o Y ||
 * =========================================================
 * ----------------------------------------------
 * User Mack Qin
 * Copy right 2019-2029 kiry 保留所有权利。
 * ----------------------------------------------
 * =========================================================
 */

return [
    [
        'name' => 'ALI_PAY_CONFIG',
        'title' => '支付宝支付编辑',
        'url' => 'alipay://admin/pay/config',
        'parent' => 'CONFIG_PAY',
        'is_show' => 0,
        'is_control' => 1,
        'is_icon' => 0,
        'picture' => '',
        'picture_select' => '',
        'sort' => 1,
    ],
];
