<?php
/**
 * KirySaaS--------||bai T o o Y ||
 * =========================================================
 * ----------------------------------------------
 * User Mack Qin
 * Copy right 2019-2029 kiry 保留所有权利。
 * ----------------------------------------------
 * =========================================================
 */


namespace addon\discount\api\controller;

use app\api\controller\BaseApi;

/**
 * 限时折扣
 */
class Discount extends BaseApi
{

}