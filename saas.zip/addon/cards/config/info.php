<?php
// +---------------------------------------------------------------------+
// | NiuCloud | [ WE CAN DO IT JUST NiuCloud ]                |
// +---------------------------------------------------------------------+
// | Copy right 2019-2029 www.niucloud.com                          |
// +---------------------------------------------------------------------+
// | Author | NiuCloud <niucloud@outlook.com>                       |
// +---------------------------------------------------------------------+
// | Repository | https://github.com/niucloud/framework.git          |
// +---------------------------------------------------------------------+
return [
	'name' => 'cards',
	'title' => '刮刮乐',
	'icon' => 'addon/cards/icon.png',
	'description' => '刮刮乐管理活动',
	'status' => 1,
	'author' => '',
    'version' => '4.0.6',
    'version_no' => '202009180001',
	'content' => '',
];
